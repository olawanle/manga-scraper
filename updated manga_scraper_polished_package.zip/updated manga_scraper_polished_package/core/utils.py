import aiohttp
import asyncio
from random import choice
from fake_useragent import UserAgent

ua = UserAgent()

async def fetch_html(url, timeout=30, ssl_verify=True):
    """
    Fetch HTML content from URL with proper error handling
    """
    headers = {"User-Agent": ua.random}
    
    try:
        timeout_obj = aiohttp.ClientTimeout(total=timeout)
        connector = aiohttp.TCPConnector(ssl=False) if not ssl_verify else None
        
        async with aiohttp.ClientSession(
            timeout=timeout_obj, 
            connector=connector
        ) as session:
            async with session.get(url, headers=headers) as resp:
                if resp.status == 200:
                    return await resp.text()
                else:
                    print(f"[ERROR] HTTP {resp.status} for {url}")
                    return None
    except asyncio.TimeoutError:
        print(f"[ERROR] Timeout while fetching {url}")
        return None
    except Exception as e:
        print(f"[ERROR] Failed to fetch {url}: {str(e)}")
        return None