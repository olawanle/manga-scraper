import sqlite3
import os

def init_db():
    """
    Initialize database with proper error handling
    """
    try:
        # Ensure output directory exists
        os.makedirs("output", exist_ok=True)
        
        conn = sqlite3.connect("db.sqlite3")
        cursor = conn.cursor()
        
        # Create table with better schema
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS chapters (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                chapter TEXT NOT NULL,
                site TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(title, chapter, site)
            )
        """)
        conn.commit()
        return conn, cursor
    except Exception as e:
        print(f"[ERROR] Database initialization failed: {str(e)}")
        raise

def is_duplicate(cursor, title, chapter, site):
    """
    Check if chapter already exists in database
    """
    try:
        cursor.execute(
            "SELECT 1 FROM chapters WHERE title=? AND chapter=? AND site=?",
            (title, chapter, site)
        )
        return cursor.fetchone() is not None
    except Exception as e:
        print(f"[ERROR] Database query failed: {str(e)}")
        return False

def save_metadata(cursor, conn, title, chapter, site):
    """
    Save chapter metadata to database with error handling
    """
    try:
        cursor.execute(
            "INSERT OR IGNORE INTO chapters (title, chapter, site) VALUES (?, ?, ?)",
            (title, chapter, site)
        )
        conn.commit()
        print(f"[INFO] Saved metadata: {title} Chapter {chapter} from {site}")
    except Exception as e:
        print(f"[ERROR] Failed to save metadata: {str(e)}")
        conn.rollback()