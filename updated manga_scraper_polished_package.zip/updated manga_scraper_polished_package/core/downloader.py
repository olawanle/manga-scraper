import aiohttp
import aiofiles
import os
import asyncio
from urllib.parse import urljoin

async def download_chapter(image_urls, folder, max_retries=3):
    """
    Download chapter images with error handling and retry logic
    """
    if not image_urls:
        print(f"[WARN] No images to download for {folder}")
        return False
        
    os.makedirs(folder, exist_ok=True)
    downloaded_count = 0
    
    async with aiohttp.ClientSession() as session:
        for i, url in enumerate(image_urls):
            if not url:
                continue
                
            path = os.path.join(folder, f"{i:03}.jpg")
            
            # Skip if file already exists
            if os.path.exists(path):
                print(f"[INFO] File already exists: {path}")
                downloaded_count += 1
                continue
            
            # Retry logic
            for attempt in range(max_retries):
                try:
                    async with session.get(url, timeout=30) as resp:
                        if resp.status == 200:
                            async with aiofiles.open(path, 'wb') as f:
                                await f.write(await resp.read())
                            print(f"[INFO] Downloaded: {os.path.basename(path)}")
                            downloaded_count += 1
                            break
                        else:
                            print(f"[ERROR] HTTP {resp.status} for {url}")
                            if attempt == max_retries - 1:
                                print(f"[ERROR] Failed to download after {max_retries} attempts: {url}")
                except asyncio.TimeoutError:
                    print(f"[ERROR] Timeout downloading {url} (attempt {attempt + 1})")
                    if attempt == max_retries - 1:
                        print(f"[ERROR] Failed to download after {max_retries} attempts: {url}")
                except Exception as e:
                    print(f"[ERROR] Error downloading {url}: {str(e)} (attempt {attempt + 1})")
                    if attempt == max_retries - 1:
                        print(f"[ERROR] Failed to download after {max_retries} attempts: {url}")
                await asyncio.sleep(1)  # Brief delay between retries
    
    print(f"[INFO] Downloaded {downloaded_count}/{len(image_urls)} images to {folder}")
    return downloaded_count > 0