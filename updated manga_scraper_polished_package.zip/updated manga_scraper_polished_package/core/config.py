import json
import os

def get_config():
    """
    Get application configuration with validation
    """
    config = {
        "output_dir": "output",
        "upload_enabled": False,
        "upload_format": "pdf",
        "proxy_list": [],
        "buzzheavier_api_key": os.getenv("BUZZHEAVIER_API_KEY", "your_api_key_here"),
        "sites": [
            "mangalivre", "working_demo"
        ],
        "download_settings": {
            "max_retries": 3,
            "timeout": 30,
            "delay_between_requests": 1,
            "max_concurrent_downloads": 5
        },
        "database": {
            "path": "db.sqlite3",
            "backup_enabled": True
        },
        "browser_scraping": {
            "enabled": False,
            "chrome_path": None,
            "headless": True
        }
    }
    
    # Ensure output directory exists
    os.makedirs(config["output_dir"], exist_ok=True)
    
    return config

def validate_config(config):
    """
    Validate configuration settings
    """
    errors = []
    
    if not config["sites"]:
        errors.append("No sites configured")
    
    if config["upload_enabled"] and config["buzzheavier_api_key"] == "your_api_key_here":
        errors.append("Upload enabled but no API key configured")
    
    return errors