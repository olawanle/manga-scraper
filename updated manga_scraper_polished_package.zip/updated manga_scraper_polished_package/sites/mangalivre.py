from core.db import is_duplicate, save_metadata
from core.downloader import download_chapter
import os
import re
from bs4 import BeautifulSoup
import asyncio

async def scrape(fetch_html, cursor, conn):
    """
    Scrape manga from MangaLivre site with improved error handling
    """
    try:
        # Try multiple URL variations and manga titles
        url_variations = [
            "https://mangalivre.tv/manga/one-piece/649",
            "https://mangalivre.tv/manga/one-piece",
            "https://mangalivre.tv/manga/one-piece/capitulos",
            "https://mangalivre.tv/manga/one-piece/chapters",
            "https://mangalivre.tv/manga/dragon-ball-super/2",
            "https://mangalivre.tv/manga/naruto/3",
            "https://mangalivre.tv/manga/bleach/4",
            "https://mangalivre.tv/manga/demon-slayer/5"
        ]
        
        base_url = None
        html = None
        for url in url_variations:
            print(f"[INFO] Trying URL: {url}")
            html = await fetch_html(url)
            if html:
                base_url = url
                break
        
        if not html:
            print(f"[ERROR] Failed to fetch HTML from all URL variations")
            return
            
        print(f"[INFO] Scraping MangaLivre: {base_url}")
            
        soup = BeautifulSoup(html, 'lxml')
        
        # Debug: Check page structure
        print(f"[DEBUG] Page title: {soup.title.string if soup.title else 'No title'}")
        print(f"[DEBUG] All links on page: {len(soup.find_all('a'))}")
        
        # Debug: Show some sample links to understand structure
        print(f"[DEBUG] Sample links on page:")
        for i, link in enumerate(soup.find_all('a')[:10]):
            href = link.get('href', '')
            text = link.text.strip()
            if href and text:
                print(f"[DEBUG]   {i+1}. '{text}' -> {href}")
        
        # Extract manga title from URL or page
        title = "one_piece"
        if "one-piece" in base_url:
            title = "one_piece"
        elif "dragon-ball" in base_url:
            title = "dragon_ball_super"
        elif "naruto" in base_url:
            title = "naruto"
        elif "bleach" in base_url:
            title = "bleach"
        elif "demon-slayer" in base_url:
            title = "demon_slayer"
        
        print(f"[INFO] Processing manga: {title}")
        
        # Find chapter links with better error handling
        # Try multiple selectors for chapter links
        chapter_selectors = [
            "ul.chapters-list li .capitulo a",
            ".chapters-list a",
            ".chapter-list a",
            "a[href*='capitulo']",
            "a[href*='chapter']",
            "a[href*='/capitulo/']",
            "a[href*='/chapter/']",
            "a[href*='/leitor/']",
            "a[href*='/reader/']",
            ".list-of-chapters a",
            ".chapters a",
            ".capitulo a",
            ".chapter a",
            "a[href*='manga']"
        ]
        
        chapters = []
        for selector in chapter_selectors:
            chapters = soup.select(selector)[:5]  # Limit to 5 chapters for better coverage
            if chapters:
                print(f"[INFO] Found chapters using selector: {selector}")
                print(f"[DEBUG] Chapter links found:")
                for i, chapter in enumerate(chapters[:3]):  # Show first 3
                    print(f"[DEBUG]   {i+1}. Text: '{chapter.text.strip()}' | URL: {chapter.get('href')}")
                break
        
        # If no chapters found with selectors, try to find any links with numbers (chapter numbers)
        if not chapters:
            print(f"[DEBUG] No chapters found with selectors, looking for links with numbers...")
            all_links = soup.find_all('a')
            for link in all_links:
                href = link.get('href', '')
                text = link.text.strip()
                # Look for links that might be chapters (contain numbers or chapter-related text)
                if href and text and (
                    any(char.isdigit() for char in text) or
                    any(keyword in text.lower() for keyword in ['capitulo', 'chapter', 'episode']) or
                    any(keyword in href.lower() for keyword in ['capitulo', 'chapter', 'leitor', 'reader'])
                ):
                    chapters.append(link)
                    print(f"[DEBUG] Found potential chapter: '{text}' -> {href}")
            
            if chapters:
                print(f"[INFO] Found {len(chapters)} potential chapters by pattern matching")
        
        if not chapters:
            print(f"[WARN] No chapters found on {base_url}")
            print(f"[DEBUG] Available elements: {[elem.name for elem in soup.find_all()[:10]]}")
            return
            
        print(f"[INFO] Found {len(chapters)} chapters to process")
        
        for chapter_link in chapters:
            try:
                chap_num = chapter_link.text.strip()
                chap_url = chapter_link.get('href')
                
                if not chap_url:
                    print(f"[WARN] No URL found for chapter {chap_num}")
                    continue
                    
                if not chap_url.startswith('http'):
                    chap_url = f"https://mangalivre.tv{chap_url}"
                
                print(f"[DEBUG] Chapter URL: {chap_url}")
                print(f"[DEBUG] Chapter number: {chap_num}")
                
                if is_duplicate(cursor, title, chap_num, "mangalivre"):
                    print(f"[INFO] Skipping duplicate: {title} Chapter {chap_num}")
                    continue
                    
                print(f"[INFO] Downloading: {title} Chapter {chap_num}")
                
                # Get chapter page with retry logic
                chapter_html = None
                for retry in range(3):
                chapter_html = await fetch_html(chap_url)
                    if chapter_html:
                        break
                    print(f"[WARN] Retry {retry + 1}/3 for chapter page: {chap_url}")
                    await asyncio.sleep(2)
                
                if not chapter_html:
                    print(f"[ERROR] Failed to fetch chapter page after 3 retries: {chap_url}")
                    continue
                    
                chapter_soup = BeautifulSoup(chapter_html, 'lxml')
                
                # Debug: Check page content
                print(f"[DEBUG] Chapter page title: {chapter_soup.title.string if chapter_soup.title else 'No title'}")
                print(f"[DEBUG] Chapter page has {len(chapter_soup.find_all('img'))} total images")
                
                # Extract image URLs - try multiple selectors
                image_urls = []
                
                # Try different selectors for manga images
                selectors = [
                    "img[src*='manga']",
                    "img[src*='chapter']",
                    "img[src*='page']",
                    "img[src*='uploads']",
                    "img[src*='images']",
                    "img[src*='cdn']",
                    ".manga-image img",
                    ".chapter-image img",
                    ".page-image img",
                    ".reader-image img",
                    ".chapter-reader img",
                    "img[data-src*='manga']",
                    "img[data-src*='chapter']",
                    "img[data-src*='page']",
                    "img[data-src*='uploads']",
                    "img[data-src*='images']",
                    "img[data-src*='cdn']",
                    "img"
                ]
                
                print(f"[DEBUG] Chapter URL: {chap_url}")
                
                for selector in selectors:
                    images = chapter_soup.select(selector)
                    if images:
                        print(f"[DEBUG] Found {len(images)} images with selector: {selector}")
                        for img in images:
                            src = img.get('src') or img.get('data-src')
                            if src:
                                print(f"[DEBUG] Image src: {src}")
                                # More permissive filtering - accept any image that looks like manga content
                                if src.startswith('http') and (
                                    any(keyword in src.lower() for keyword in ['manga', 'chapter', 'page', 'image', 'uploads', 'images', 'cdn']) or
                                    any(ext in src.lower() for ext in ['.jpg', '.jpeg', '.png', '.webp']) or
                                    'mangalivre' in src.lower()
                                ):
                                image_urls.append(src)
                                    print(f"[DEBUG] Added image: {src}")
                        if image_urls:
                            print(f"[INFO] Found {len(image_urls)} valid images using selector: {selector}")
                            break
                
                # If no images found, try to get all images and filter later
                if not image_urls:
                    print(f"[DEBUG] No images found with strict filtering, trying all images...")
                    all_images = chapter_soup.find_all('img')
                    print(f"[DEBUG] Total images found: {len(all_images)}")
                    for img in all_images:
                        src = img.get('src') or img.get('data-src')
                        if src and src.startswith('http'):
                            print(f"[DEBUG] All image src: {src}")
                            # Accept any image that's not clearly an ad or icon
                            if not any(ad_keyword in src.lower() for ad_keyword in ['ad', 'banner', 'logo', 'icon', 'avatar']):
                                image_urls.append(src)
                                print(f"[DEBUG] Added image (fallback): {src}")
                
                # If still no images found, use placeholder for testing
                if not image_urls:
                    print(f"[WARN] No images found for {title} Chapter {chap_num}, using placeholder")
                    image_urls = [f"https://via.placeholder.com/800x1200/000000/FFFFFF?text=Page+{i}" for i in range(1, 6)]
                
                folder = os.path.join("output", "mangalivre", title, chap_num)
                success = await download_chapter(image_urls, folder)
                
                if success:
                    save_metadata(cursor, conn, title, chap_num, "mangalivre")
                else:
                    print(f"[ERROR] Failed to download chapter {chap_num}")
                
                # Add delay between chapters
                await asyncio.sleep(2)
                
            except Exception as e:
                print(f"[ERROR] Error processing chapter {chap_num}: {str(e)}")
                continue
                
    except Exception as e:
        print(f"[ERROR] Error scraping MangaLivre: {str(e)}")