from sites import mangalivre, atemporal, apecomics, mangadex, mangareader, mangafox, mangakakalot, mangapanda, mangadex_working, working_demo

SITE_HANDLERS = {
    "mangalivre": mangalivre.scrape,
    "atemporal": atemporal.scrape,
    "apecomics": apecomics.scrape,
    "mangadex": mangadex.scrape,
    "mangareader": mangareader.scrape,
    "mangafox": mangafox.scrape,
    "mangakakalot": mangakakalot.scrape,
    "mangapanda": mangapanda.scrape,
    "mangadex_working": mangadex_working.scrape,
    "working_demo": working_demo.scrape
}