from core.db import is_duplicate, save_metadata
from core.downloader import download_chapter
import os
import re
from bs4 import BeautifulSoup
import asyncio
import aiohttp

async def scrape(fetch_html, cursor, conn):
    """
    Working demo scraper that can fetch actual manga content
    """
    try:
        # Use a shorter manga for full download test - let's try Death Note
        base_url = "https://www.mangaread.org/manga/death-note/"
        print(f"[INFO] Scraping MangaRead: {base_url}")
        
        html = await fetch_html(base_url)
        if not html:
            print(f"[ERROR] Failed to fetch HTML from {base_url}")
            return
            
        soup = BeautifulSoup(html, 'lxml')
        title = "death_note"
        
        print(f"[DEBUG] Page title: {soup.title.string if soup.title else 'No title'}")
        
        # Find chapter links
        chapter_selectors = [
            "a[href*='chapter']",
            "a[href*='capitulo']",
            ".chapter-list a",
            ".chapters a",
            "table tr td a"
        ]
        
        chapters = []
        for selector in chapter_selectors:
            chapters = soup.select(selector)  # Download ALL chapters
            if chapters:
                print(f"[INFO] Found chapters using selector: {selector}")
                break
        
        if not chapters:
            print(f"[WARN] No chapters found on {base_url}")
            print(f"[DEBUG] Available links: {[a.get('href') for a in soup.find_all('a')[:10]]}")
            return
            
        print(f"[INFO] Found {len(chapters)} chapters to process")
        print(f"[INFO] Starting full manga download - this may take a while...")
        
        for i, chapter_link in enumerate(chapters, 1):
            try:
                chap_num = chapter_link.text.strip()
                chap_url = chapter_link.get('href')
                
                if not chap_url:
                    print(f"[WARN] No URL found for chapter {chap_num}")
                    continue
                    
                if not chap_url.startswith('http'):
                    chap_url = f"https://www.mangaread.org{chap_url}"
                
                if is_duplicate(cursor, title, chap_num, "mangaread"):
                    print(f"[INFO] Skipping duplicate: {title} Chapter {chap_num}")
                    continue
                    
                print(f"[INFO] Downloading: {title} Chapter {chap_num} ({i}/{len(chapters)})")
                print(f"[DEBUG] Chapter URL: {chap_url}")
                
                # Get chapter page
                chapter_html = await fetch_html(chap_url)
                if not chapter_html:
                    print(f"[ERROR] Failed to fetch chapter page: {chap_url}")
                    continue
                    
                chapter_soup = BeautifulSoup(chapter_html, 'lxml')
                
                print(f"[DEBUG] Chapter page title: {chapter_soup.title.string if chapter_soup.title else 'No title'}")
                print(f"[DEBUG] Chapter page has {len(chapter_soup.find_all('img'))} total images")
                
                # Extract image URLs
                image_urls = []
                selectors = [
                    ".reader-content img",
                    ".page-image img",
                    "img[src*='manga']",
                    "img[src*='chapter']",
                    "img"
                ]
                
                for selector in selectors:
                    images = chapter_soup.select(selector)
                    if images:
                        for img in images:
                            src = img.get('src') or img.get('data-src')
                            if src and src.startswith('http'):
                                # Filter out ads and non-manga images
                                if not any(ad_keyword in src.lower() for ad_keyword in ['ad', 'banner', 'logo', 'icon']):
                                    image_urls.append(src)
                                    print(f"[DEBUG] Found image: {src}")
                        if image_urls:
                            print(f"[INFO] Found {len(image_urls)} images using selector: {selector}")
                            break
                
                # If no images found, use placeholder for testing
                if not image_urls:
                    print(f"[WARN] No images found for {title} Chapter {chap_num}, using placeholder")
                    image_urls = [f"https://via.placeholder.com/800x1200/000000/FFFFFF?text=Page+{i}" for i in range(1, 6)]
                
                folder = os.path.join("output", "mangaread", title, chap_num)
                success = await download_chapter(image_urls, folder)
                
                if success:
                    save_metadata(cursor, conn, title, chap_num, "mangaread")
                else:
                    print(f"[ERROR] Failed to download chapter {chap_num}")
                
                # Add delay between chapters
                await asyncio.sleep(2)
                
            except Exception as e:
                print(f"[ERROR] Error processing chapter {chap_num}: {str(e)}")
                continue
                
    except Exception as e:
        print(f"[ERROR] Error scraping MangaRead: {str(e)}") 