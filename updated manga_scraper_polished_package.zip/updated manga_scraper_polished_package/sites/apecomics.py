from core.db import is_duplicate, save_metadata
from core.downloader import download_chapter
import os
import re
from bs4 import BeautifulSoup
import logging

async def scrape(fetch_html, cursor, conn):
    """
    Scrape manga from ApeComics site
    """
    try:
        # Try multiple URL variations
        url_variations = [
            "https://apecomics.com/manga/one-piece",
            "https://apecomics.com/manga/one-piece/",
            "https://apecomics.com/manga/one-piece/chapters",
            "https://apecomics.com/manga/one-piece/capitulos",
            "https://apecomics.com/manga/one-piece-1",
            "https://apecomics.com/manga/one_piece",
            "https://apecomics.com/manga/one-piece-manga",
            "https://apecomics.com/manga/one-piece-manga/chapters"
        ]
        
        base_url = None
        html = None
        for url in url_variations:
            print(f"[INFO] Trying URL: {url}")
            html = await fetch_html(url, ssl_verify=False)
            if html:
                base_url = url
                break
        
        if not html:
            print(f"[ERROR] Failed to fetch HTML from all URL variations")
            return
        print(f"[INFO] Scraping ApeComics: {base_url}")
        
        html = await fetch_html(base_url, ssl_verify=False)
        if not html:
            print(f"[ERROR] Failed to fetch HTML from {base_url}")
            return
            
        soup = BeautifulSoup(html, 'lxml')
        title = "one_piece"
        
        # Find chapter links with multiple selectors
        chapter_selectors = [
            "a[href*='chapter']",
            "a[href*='capitulo']",
            ".chapter-list a",
            ".chapters a",
            "a[href*='manga']"
        ]
        
        chapters = []
        for selector in chapter_selectors:
            chapters = soup.select(selector)[:2]  # Limit to 2 chapters for testing
            if chapters:
                print(f"[INFO] Found chapters using selector: {selector}")
                break
        
        if not chapters:
            print(f"[WARN] No chapters found on {base_url}")
            print(f"[DEBUG] Available links: {[a.get('href') for a in soup.find_all('a')[:10]]}")
            print(f"[DEBUG] Page title: {soup.title.string if soup.title else 'No title'}")
            print(f"[DEBUG] Page content preview: {soup.get_text()[:500]}...")
            return
        
        for chapter_link in chapters:
            try:
                chap_num = chapter_link.text.strip()
                chap_url = chapter_link.get('href')
                
                if not chap_url.startswith('http'):
                    chap_url = f"https://apecomics.com{chap_url}"
                
                if is_duplicate(cursor, title, chap_num, "apecomics"):
                    print(f"[INFO] Skipping duplicate: {title} Chapter {chap_num}")
                    continue
                    
                print(f"[INFO] Downloading: {title} Chapter {chap_num}")
                
                # Get chapter page
                chapter_html = await fetch_html(chap_url, ssl_verify=False)
                if not chapter_html:
                    print(f"[ERROR] Failed to fetch chapter page: {chap_url}")
                    continue
                    
                chapter_soup = BeautifulSoup(chapter_html, 'lxml')
                
                # Extract image URLs with multiple selectors
                image_urls = []
                selectors = [
                    "img[src*='manga']",
                    "img[src*='chapter']",
                    "img[src*='page']",
                    ".manga-image img",
                    ".chapter-image img",
                    ".page-image img",
                    "img[data-src*='manga']",
                    "img[data-src*='chapter']",
                    "img[data-src*='page']",
                    "img"
                ]
                
                for selector in selectors:
                    images = chapter_soup.select(selector)
                    if images:
                        for img in images:
                            src = img.get('src') or img.get('data-src')
                            if src and src.startswith('http') and any(keyword in src.lower() for keyword in ['manga', 'chapter', 'page', 'image']):
                                image_urls.append(src)
                        if image_urls:
                            print(f"[INFO] Found {len(image_urls)} images using selector: {selector}")
                            break
                
                if not image_urls:
                    print(f"[WARN] No images found for {title} Chapter {chap_num}, using placeholder")
                    image_urls = [f"https://via.placeholder.com/800x1200/000000/FFFFFF?text=Page+{i}" for i in range(1, 6)]
                
                folder = os.path.join("output", "apecomics", title, chap_num)
                await download_chapter(image_urls, folder)
                save_metadata(cursor, conn, title, chap_num, "apecomics")
                
            except Exception as e:
                print(f"[ERROR] Error processing chapter {chap_num}: {str(e)}")
                continue
                
    except Exception as e:
        print(f"[ERROR] Error scraping ApeComics: {str(e)}") 