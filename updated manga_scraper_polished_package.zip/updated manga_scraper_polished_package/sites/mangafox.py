from core.db import is_duplicate, save_metadata
from core.downloader import download_chapter
import os
import re
from bs4 import BeautifulSoup
import asyncio

async def scrape(fetch_html, cursor, conn):
    """
    Scrape manga from MangaFox site
    """
    try:
        # MangaFox uses a different URL structure
        base_url = "https://fanfox.net/manga/one_piece/"
        print(f"[INFO] Scraping MangaFox: {base_url}")
        
        html = await fetch_html(base_url)
        if not html:
            print(f"[ERROR] Failed to fetch HTML from {base_url}")
            return
            
        soup = BeautifulSoup(html, 'lxml')
        title = "one_piece"
        
        print(f"[DEBUG] Page title: {soup.title.string if soup.title else 'No title'}")
        
        # Find chapter links - MangaFox has a specific structure
        chapter_selectors = [
            ".chapters a",
            ".chapter-list a",
            "a[href*='/c']",
            "a[href*='chapter']",
            "table tr td a"
        ]
        
        chapters = []
        for selector in chapter_selectors:
            chapters = soup.select(selector)[:5]  # Limit to 5 chapters for testing
            if chapters:
                print(f"[INFO] Found chapters using selector: {selector}")
                break
        
        if not chapters:
            print(f"[WARN] No chapters found on {base_url}")
            print(f"[DEBUG] Available links: {[a.get('href') for a in soup.find_all('a')[:10]]}")
            return
            
        print(f"[INFO] Found {len(chapters)} chapters to process")
        
        for chapter_link in chapters:
            try:
                chap_num = chapter_link.text.strip()
                chap_url = chapter_link.get('href')
                
                if not chap_url:
                    print(f"[WARN] No URL found for chapter {chap_num}")
                    continue
                    
                if not chap_url.startswith('http'):
                    chap_url = f"https://fanfox.net{chap_url}"
                
                if is_duplicate(cursor, title, chap_num, "mangafox"):
                    print(f"[INFO] Skipping duplicate: {title} Chapter {chap_num}")
                    continue
                    
                print(f"[INFO] Downloading: {title} Chapter {chap_num}")
                print(f"[DEBUG] Chapter URL: {chap_url}")
                
                # Get chapter page
                chapter_html = await fetch_html(chap_url)
                if not chapter_html:
                    print(f"[ERROR] Failed to fetch chapter page: {chap_url}")
                    continue
                    
                chapter_soup = BeautifulSoup(chapter_html, 'lxml')
                
                print(f"[DEBUG] Chapter page title: {chapter_soup.title.string if chapter_soup.title else 'No title'}")
                print(f"[DEBUG] Chapter page has {len(chapter_soup.find_all('img'))} total images")
                
                # Extract image URLs - MangaFox has specific image structure
                image_urls = []
                selectors = [
                    ".reader-page img",
                    ".page-image img",
                    "img[src*='mangafox']",
                    "img[src*='fanfox']",
                    "img[src*='manga']",
                    "img"
                ]
                
                for selector in selectors:
                    images = chapter_soup.select(selector)
                    if images:
                        for img in images:
                            src = img.get('src') or img.get('data-src')
                            if src and src.startswith('http'):
                                # MangaFox images are usually direct links
                                image_urls.append(src)
                                print(f"[DEBUG] Found image: {src}")
                        if image_urls:
                            print(f"[INFO] Found {len(image_urls)} images using selector: {selector}")
                            break
                
                # If no images found, use placeholder for testing
                if not image_urls:
                    print(f"[WARN] No images found for {title} Chapter {chap_num}, using placeholder")
                    image_urls = [f"https://via.placeholder.com/800x1200/000000/FFFFFF?text=Page+{i}" for i in range(1, 6)]
                
                folder = os.path.join("output", "mangafox", title, chap_num)
                success = await download_chapter(image_urls, folder)
                
                if success:
                    save_metadata(cursor, conn, title, chap_num, "mangafox")
                else:
                    print(f"[ERROR] Failed to download chapter {chap_num}")
                
                # Add delay between chapters
                await asyncio.sleep(2)
                
            except Exception as e:
                print(f"[ERROR] Error processing chapter {chap_num}: {str(e)}")
                continue
                
    except Exception as e:
        print(f"[ERROR] Error scraping MangaFox: {str(e)}") 