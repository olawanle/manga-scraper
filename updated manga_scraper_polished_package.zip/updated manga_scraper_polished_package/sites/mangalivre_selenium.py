from core.db import is_duplicate, save_metadata
from core.downloader import download_chapter
import os
import re
from bs4 import BeautifulSoup
import asyncio
import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.options import Options

async def scrape(fetch_html, cursor, conn):
    """
    Scrape manga from MangaLivre site using Selenium for JavaScript support
    """
    try:
        # Set up Chrome options for headless browsing
        chrome_options = Options()
        chrome_options.add_argument("--headless")
        chrome_options.add_argument("--no-sandbox")
        chrome_options.add_argument("--disable-dev-shm-usage")
        chrome_options.add_argument("--disable-gpu")
        chrome_options.add_argument("--window-size=1920,1080")
        chrome_options.add_argument("--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36")
        
        # Initialize the driver
        driver = webdriver.Chrome(options=chrome_options)
        wait = WebDriverWait(driver, 10)
        
        try:
            base_url = "https://mangalivre.tv/manga/one-piece/649"
            print(f"[INFO] Scraping MangaLivre with Selenium: {base_url}")
            
            # Navigate to the page
            driver.get(base_url)
            
            # Wait for page to load
            time.sleep(3)
            
            # Wait for content to load
            try:
                wait.until(EC.presence_of_element_located((By.TAG_NAME, "body")))
            except:
                print("[WARN] Page load timeout, continuing anyway")
            
            # Get the page source after JavaScript execution
            html = driver.page_source
            soup = BeautifulSoup(html, 'lxml')
            title = "one_piece"
            
            print(f"[DEBUG] Page title: {soup.title.string if soup.title else 'No title'}")
            
            # Look for chapter links that might be loaded by JavaScript
            chapter_selectors = [
                "a[href*='capitulo']",
                "a[href*='chapter']",
                "a[href*='leitor']",
                "a[href*='reader']",
                ".chapter-list a",
                ".chapters a",
                ".capitulo a",
                ".chapter a"
            ]
            
            chapters = []
            for selector in chapter_selectors:
                chapters = soup.select(selector)[:5]  # Limit to 5 chapters for testing
                if chapters:
                    print(f"[INFO] Found chapters using selector: {selector}")
                    break
            
            # If no chapters found, try to click on "Read First" or "Read Last" buttons
            if not chapters:
                print(f"[DEBUG] No chapters found with selectors, trying to find read buttons...")
                try:
                    # Look for "Read First" or "Read Last" buttons
                    read_buttons = driver.find_elements(By.XPATH, "//a[contains(text(), 'Read')]")
                    if read_buttons:
                        print(f"[INFO] Found {len(read_buttons)} read buttons")
                        # Click on the first read button to see if it leads to chapters
                        read_buttons[0].click()
                        time.sleep(3)
                        
                        # Get the new page source
                        html = driver.page_source
                        soup = BeautifulSoup(html, 'lxml')
                        
                        # Try to find chapters again
                        for selector in chapter_selectors:
                            chapters = soup.select(selector)[:5]
                            if chapters:
                                print(f"[INFO] Found chapters after clicking read button using selector: {selector}")
                                break
                except Exception as e:
                    print(f"[DEBUG] Error clicking read button: {e}")
            
            if not chapters:
                print(f"[WARN] No chapters found on {base_url}")
                print(f"[DEBUG] Available links: {[a.get('href') for a in soup.find_all('a')[:10]]}")
                return
            
            print(f"[INFO] Found {len(chapters)} chapters to process")
            
            for chapter_link in chapters:
                try:
                    chap_num = chapter_link.text.strip()
                    chap_url = chapter_link.get('href')
                    
                    if not chap_url:
                        print(f"[WARN] No URL found for chapter {chap_num}")
                        continue
                        
                    if not chap_url.startswith('http'):
                        chap_url = f"https://mangalivre.tv{chap_url}"
                    
                    if is_duplicate(cursor, title, chap_num, "mangalivre"):
                        print(f"[INFO] Skipping duplicate: {title} Chapter {chap_num}")
                        continue
                        
                    print(f"[INFO] Downloading: {title} Chapter {chap_num}")
                    
                    # Navigate to chapter page
                    driver.get(chap_url)
                    time.sleep(3)
                    
                    # Wait for chapter content to load
                    try:
                        wait.until(EC.presence_of_element_located((By.TAG_NAME, "img")))
                    except:
                        print("[WARN] Chapter page load timeout, continuing anyway")
                    
                    # Get chapter page source
                    chapter_html = driver.page_source
                    chapter_soup = BeautifulSoup(chapter_html, 'lxml')
                    
                    # Extract image URLs with multiple selectors
                    image_urls = []
                    selectors = [
                        "img[src*='manga']",
                        "img[src*='chapter']",
                        "img[src*='page']",
                        ".manga-image img",
                        ".chapter-image img",
                        ".page-image img",
                        "img[data-src*='manga']",
                        "img[data-src*='chapter']",
                        "img[data-src*='page']",
                        "img"
                    ]
                    
                    for selector in selectors:
                        images = chapter_soup.select(selector)
                        if images:
                            for img in images:
                                src = img.get('src') or img.get('data-src')
                                if src and src.startswith('http') and any(keyword in src.lower() for keyword in ['manga', 'chapter', 'page', 'image']):
                                    image_urls.append(src)
                            if image_urls:
                                print(f"[INFO] Found {len(image_urls)} images using selector: {selector}")
                                break
                    
                    if not image_urls:
                        print(f"[WARN] No images found for {title} Chapter {chap_num}, using placeholder")
                        image_urls = [f"https://via.placeholder.com/800x1200/000000/FFFFFF?text=Page+{i}" for i in range(1, 6)]
                    
                    folder = os.path.join("output", "mangalivre", title, chap_num)
                    success = await download_chapter(image_urls, folder)
                    
                    if success:
                        save_metadata(cursor, conn, title, chap_num, "mangalivre")
                    else:
                        print(f"[ERROR] Failed to download chapter {chap_num}")
                    
                    # Add delay between chapters
                    await asyncio.sleep(2)
                    
                except Exception as e:
                    print(f"[ERROR] Error processing chapter {chap_num}: {str(e)}")
                    continue
                    
        finally:
            driver.quit()
                
    except Exception as e:
        print(f"[ERROR] Error scraping MangaLivre: {str(e)}") 