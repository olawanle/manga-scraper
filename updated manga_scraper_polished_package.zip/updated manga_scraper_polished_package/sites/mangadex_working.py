from core.db import is_duplicate, save_metadata
from core.downloader import download_chapter
import os
import re
from bs4 import BeautifulSoup
import asyncio
import aiohttp
import json

async def scrape(fetch_html, cursor, conn):
    """
    Scrape manga from MangaDex using their API
    """
    try:
        # MangaDex API endpoint for One Piece
        manga_id = "a1c7c817-4e59-43b7-9365-09675e9a9df6"  # One Piece manga ID
        api_url = f"https://api.mangadex.org/manga/{manga_id}/feed"
        
        print(f"[INFO] Scraping MangaDex API: {api_url}")
        
        # Use aiohttp to fetch JSON data
        headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"}
        
        async with aiohttp.ClientSession() as session:
            async with session.get(api_url, headers=headers) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    chapters = data.get('data', [])
                    
                    print(f"[INFO] Found {len(chapters)} chapters via API")
                    
                    # Filter for English chapters and sort by chapter number
                    english_chapters = []
                    for chapter in chapters:
                        if chapter.get('attributes', {}).get('translatedLanguage') == 'en':
                            english_chapters.append(chapter)
                    
                    # Sort by chapter number
                    english_chapters.sort(key=lambda x: float(x.get('attributes', {}).get('chapter', 0) or 0))
                    
                    # Take the latest 2 chapters for testing
                    chapters_to_process = english_chapters[:2]
                    
                    title = "one_piece"
                    
                    for chapter in chapters_to_process:
                        try:
                            chap_num = chapter.get('attributes', {}).get('chapter', 'Unknown')
                            chap_id = chapter.get('id')
                            
                            if is_duplicate(cursor, title, chap_num, "mangadex"):
                                print(f"[INFO] Skipping duplicate: {title} Chapter {chap_num}")
                                continue
                            
                            print(f"[INFO] Downloading: {title} Chapter {chap_num}")
                            
                            # Get chapter pages
                            pages_url = f"https://api.mangadex.org/at-home/server/{chap_id}"
                            async with session.get(pages_url, headers=headers) as pages_resp:
                                if pages_resp.status == 200:
                                    pages_data = await pages_resp.json()
                                    base_url = pages_data['baseUrl']
                                    chapter_hash = pages_data['chapter']['hash']
                                    
                                    # Get page list
                                    pages = pages_data['chapter']['data']
                                    image_urls = []
                                    
                                    for page in pages:
                                        image_url = f"{base_url}/data/{chapter_hash}/{page}"
                                        image_urls.append(image_url)
                                        print(f"[DEBUG] Found image: {image_url}")
                                    
                                    if image_urls:
                                        print(f"[INFO] Found {len(image_urls)} images for chapter {chap_num}")
                                        
                                        folder = os.path.join("output", "mangadex", title, str(chap_num))
                                        success = await download_chapter(image_urls, folder)
                                        
                                        if success:
                                            save_metadata(cursor, conn, title, str(chap_num), "mangadex")
                                        else:
                                            print(f"[ERROR] Failed to download chapter {chap_num}")
                                    else:
                                        print(f"[WARN] No images found for chapter {chap_num}")
                                else:
                                    print(f"[ERROR] Failed to get chapter pages: {pages_resp.status}")
                            
                            # Add delay between chapters
                            await asyncio.sleep(2)
                            
                        except Exception as e:
                            print(f"[ERROR] Error processing chapter {chap_num}: {str(e)}")
                            continue
                            
                else:
                    print(f"[ERROR] Failed to fetch manga data: {resp.status}")
                    
    except Exception as e:
        print(f"[ERROR] Error scraping MangaDex: {str(e)}") 