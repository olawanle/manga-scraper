import asyncio
import aiohttp
from bs4 import BeautifulSoup
from fake_useragent import UserAgent

ua = UserAgent()

async def test_chapter_urls():
    """Test different chapter URL patterns"""
    base_urls = [
        "https://mangalivre.tv/manga/one-piece/649",
        "https://mangalivre.tv/manga/one-piece/649/capitulos",
        "https://mangalivre.tv/manga/one-piece/649/chapters",
        "https://mangalivre.tv/manga/one-piece/649/lista-de-capitulos",
        "https://mangalivre.tv/manga/one-piece/capitulos",
        "https://mangalivre.tv/manga/one-piece/chapters",
        "https://mangalivre.tv/manga/one-piece/649/leitor",
        "https://mangalivre.tv/manga/one-piece/649/reader"
    ]
    
    headers = {"User-Agent": ua.random}
    
    for url in base_urls:
        print(f"\nTesting URL: {url}")
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(url, headers=headers) as resp:
                    if resp.status == 200:
                        html = await resp.text()
                        soup = BeautifulSoup(html, 'lxml')
                        
                        print(f"  Status: {resp.status}")
                        print(f"  Title: {soup.title.string if soup.title else 'No title'}")
                        
                        # Look for chapter links
                        chapter_links = []
                        for link in soup.find_all('a'):
                            href = link.get('href', '')
                            text = link.text.strip()
                            if href and any(keyword in href.lower() for keyword in ['capitulo', 'chapter', 'leitor', 'reader']):
                                chapter_links.append((text, href))
                        
                        if chapter_links:
                            print(f"  Found {len(chapter_links)} potential chapter links:")
                            for text, href in chapter_links[:5]:
                                print(f"    '{text}' -> {href}")
                        else:
                            print("  No chapter links found")
                            
                    else:
                        print(f"  Status: {resp.status}")
                        
        except Exception as e:
            print(f"  Error: {e}")

if __name__ == "__main__":
    asyncio.run(test_chapter_urls()) 