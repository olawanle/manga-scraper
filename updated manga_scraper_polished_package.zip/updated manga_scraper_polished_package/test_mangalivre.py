import asyncio
import aiohttp
from bs4 import BeautifulSoup
from fake_useragent import UserAgent

ua = UserAgent()

async def test_mangalivre():
    """Test script to examine MangaLivre page structure"""
    url = "https://mangalivre.tv/manga/one-piece/649"
    headers = {"User-Agent": ua.random}
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url, headers=headers) as resp:
                if resp.status == 200:
                    html = await resp.text()
                    soup = BeautifulSoup(html, 'lxml')
                    
                    print(f"Page title: {soup.title.string if soup.title else 'No title'}")
                    print(f"Total links: {len(soup.find_all('a'))}")
                    
                    # Look for any links that might be chapters
                    print("\nAll links with href:")
                    for i, link in enumerate(soup.find_all('a')):
                        href = link.get('href', '')
                        text = link.text.strip()
                        if href and href != '#':
                            print(f"{i+1:2d}. '{text}' -> {href}")
                    
                    # Look for specific patterns
                    print("\nLinks containing 'capitulo':")
                    for link in soup.find_all('a', href=lambda x: x and 'capitulo' in x):
                        print(f"  '{link.text.strip()}' -> {link.get('href')}")
                    
                    print("\nLinks containing 'chapter':")
                    for link in soup.find_all('a', href=lambda x: x and 'chapter' in x):
                        print(f"  '{link.text.strip()}' -> {link.get('href')}")
                    
                    print("\nLinks containing 'leitor':")
                    for link in soup.find_all('a', href=lambda x: x and 'leitor' in x):
                        print(f"  '{link.text.strip()}' -> {link.get('href')}")
                    
                    print("\nLinks containing numbers (potential chapters):")
                    for link in soup.find_all('a'):
                        text = link.text.strip()
                        if text and any(char.isdigit() for char in text):
                            print(f"  '{text}' -> {link.get('href')}")
                    
                else:
                    print(f"HTTP {resp.status}")
                    
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    asyncio.run(test_mangalivre()) 