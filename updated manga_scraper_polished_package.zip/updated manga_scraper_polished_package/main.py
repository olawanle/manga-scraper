import asyncio
import sys
import signal
from core.config import get_config
from core.db import init_db
from core.utils import fetch_html
from sites import SITE_HANDLERS

# Global variables for graceful shutdown
running = True
tasks = []

def signal_handler(signum, frame):
    """Handle shutdown signals gracefully"""
    global running
    print("\n[INFO] Shutdown signal received. Stopping gracefully...")
    running = False

async def run_all_sites():
    """Run all configured sites with proper error handling"""
    global running
    
    try:
        config = get_config()
        conn, cursor = init_db()
        
        print(f"[INFO] Starting scraper for {len(config['sites'])} sites...")
        
        for site in config["sites"]:
            if not running:
                break
                
            if site in SITE_HANDLERS:
                print(f"[INFO] Running site: {site}")
                try:
                    await SITE_HANDLERS[site](fetch_html, cursor, conn)
                except Exception as e:
                    print(f"[ERROR] Failed to scrape {site}: {str(e)}")
            else:
                print(f"[WARN] Site handler not found for: {site}")
        
        conn.close()
        print("[INFO] Database connection closed.")
        
    except Exception as e:
        print(f"[ERROR] Application error: {str(e)}")
        return False
    
    return True

async def main():
    """Main application entry point"""
    # Set up signal handlers
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    print("[INFO] Manga Scraper Starting...\n")
    
    try:
        success = await run_all_sites()
        if success:
            print("\n[INFO] Manga Scraper Finished Successfully.")
        else:
            print("\n[ERROR] Manga Scraper Finished with Errors.")
            sys.exit(1)
    except KeyboardInterrupt:
        print("\n[INFO] Interrupted by user.")
    except Exception as e:
        print(f"\n[ERROR] Unexpected error: {str(e)}")
        sys.exit(1)

if __name__ == "__main__":
    asyncio.run(main())