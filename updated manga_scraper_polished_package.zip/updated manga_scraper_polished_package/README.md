# Manga Scraper

A robust, asynchronous manga scraper that downloads chapters from multiple manga sites with proper error handling and database tracking.

## Features

- **Multi-site Support**: Scrapes from MangaLivre, Atemporal, and ApeComics
- **Async Downloads**: Fast concurrent downloading with retry logic
- **Database Tracking**: Prevents duplicate downloads using SQLite
- **Error Handling**: Comprehensive error handling and logging
- **Graceful Shutdown**: Proper signal handling for clean exits
- **Configurable**: Easy configuration management

## Installation

1. **Clone the repository**:
   ```bash
   git clone <repository-url>
   cd manga_scraper_polished_package
   ```

2. **Install dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

3. **Run the scraper**:
   ```bash
   python main.py
   ```

## Configuration

The scraper uses a configuration system in `core/config.py`. Key settings:

- `sites`: List of sites to scrape
- `output_dir`: Directory for downloaded chapters
- `download_settings`: Timeout, retry, and concurrency settings
- `database`: Database configuration

## Project Structure

```
manga_scraper_polished_package/
├── core/
│   ├── config.py      # Configuration management
│   ├── db.py          # Database operations
│   ├── downloader.py  # Image download logic
│   └── utils.py       # HTTP utilities
├── sites/
│   ├── __init__.py    # Site handler registry
│   ├── mangalivre.py  # MangaLivre scraper
│   ├── atemporal.py   # Atemporal scraper
│   └── apecomics.py   # ApeComics scraper
├── main.py            # Main application
├── requirements.txt   # Python dependencies
└── README.md         # This file
```

## Usage

### Basic Usage

```bash
python main.py
```

### Environment Variables

Set the BuzzHeavier API key (if using upload feature):
```bash
export BUZZHEAVIER_API_KEY="your_api_key_here"
```

### Docker Usage

```bash
docker build -t manga-scraper .
docker run manga-scraper
```

## Error Handling

The scraper includes comprehensive error handling:

- **Network Timeouts**: Configurable timeouts with retry logic
- **HTTP Errors**: Proper handling of 4xx/5xx responses
- **Database Errors**: Transaction rollback on failures
- **Missing Files**: Graceful handling of missing resources
- **Graceful Shutdown**: Proper cleanup on interruption

## Database Schema

The SQLite database tracks downloaded chapters:

```sql
CREATE TABLE chapters (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    chapter TEXT NOT NULL,
    site TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(title, chapter, site)
);
```

## Output Structure

Downloaded chapters are organized as:
```
output/
├── mangalivre/
│   └── one_piece/
│       └── chapter_001/
│           ├── 001.jpg
│           ├── 002.jpg
│           └── ...
├── atemporal/
└── apecomics/
```

## Troubleshooting

### Common Issues

1. **Import Errors**: Ensure all dependencies are installed
2. **Network Timeouts**: Check internet connection and site availability
3. **Permission Errors**: Ensure write permissions for output directory
4. **Database Errors**: Check SQLite file permissions

### Debug Mode

For detailed logging, modify the configuration to enable debug output.

## Contributing

1. Fork the repository
2. Create a feature branch
3. Add your changes
4. Test thoroughly
5. Submit a pull request

## License

This project is licensed under the MIT License.

## Disclaimer

This tool is for educational purposes only. Please respect website terms of service and rate limits when scraping.