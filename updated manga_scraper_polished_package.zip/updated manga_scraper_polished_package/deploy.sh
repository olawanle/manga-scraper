#!/bin/bash

echo "[INFO] Updating system..."
apt update -y && apt upgrade -y

echo "[INFO] Installing Docker..."
apt install -y docker.io unzip

echo "[INFO] Enabling Docker..."
systemctl enable docker
systemctl start docker

echo "[INFO] Unzipping project..."
unzip -o manga_scraper_full_project.zip -d /root/manga_scraper_project

echo "[INFO] Changing directory..."
cd /root/manga_scraper_project

echo "[INFO] Building Docker image..."
docker build -t manga-scraper .

echo "[INFO] Running Manga Scraper in Docker..."
docker run --rm manga-scraper

echo "[INFO] Done."